package com.pharma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PharmaceuticalManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(PharmaceuticalManagementApplication.class, args);
	}

}
